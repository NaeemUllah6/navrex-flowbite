import SignInPage from '../../components/sign-in/sign-in.component'

export default function SignInView() {
    return (
        <SignInPage />
    )
}
