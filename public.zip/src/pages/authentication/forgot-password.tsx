import ForgotPasswordPage from '../../components/forgot-password/forgot-password.component'

export default function ForgotPasswordView() {
  return (
    <ForgotPasswordPage />
  )
}
