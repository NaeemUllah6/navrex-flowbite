import ResetPasswordPage from '../../components/reset-password/reset-password.component'

export default function ResetPasswordView() {
  return (
    <ResetPasswordPage />
  )
}
