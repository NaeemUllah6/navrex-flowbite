import SignUpPage from "../../components/sign-up/sign-up.component";

export default function SignUpView() {
  return (
    <SignUpPage />
  )
}
