import PasswordResetSuccessfullyPage from "../../components/password-reset-successfully/password-reset-successfully.component";

export default function PasswordResetSuccessfully() {
    return (
        <PasswordResetSuccessfullyPage />
    )
}
