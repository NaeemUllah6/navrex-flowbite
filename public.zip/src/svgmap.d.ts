declare module "svgmap";
